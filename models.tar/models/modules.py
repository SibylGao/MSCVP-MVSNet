# Modules used in CVP-MVSNet
# By: Jiayu
# Date: 2019-08-13

# Note: This file use part of the code from the following projects.
#       Thanks for the authors for the great code.
#       MVSNet: https://github.com/YoYo000/MVSNet
#       MVSNet_pytorch: https://github.com/xy-guo/MVSNet_pytorch

import numpy as np
np.seterr(all='raise')
import torch
import torch.nn as nn
import torch.nn.functional as F
import cv2
# Debug:
# import pdb
# import matplotlib.pyplot as plt
# from verifications import *
eps = 1e-12
# UAS depth sample
def uncertainty_aware_samples(cur_depth, exp_var, ndepth):
    exp_var = nn.functional.interpolate(exp_var[None,:],size=None,scale_factor=2,mode='bicubic',align_corners=None)
    exp_var = exp_var.permute(1,0,2,3)
    cur_depth = cur_depth.unsqueeze(1)
    # if cur_depth.dim() == 2:
    #     #must be the first stage
    #     cur_depth_min = cur_depth[:, 0]  # (B,)
    #     cur_depth_max = cur_depth[:, -1]
    #     new_interval = (cur_depth_max - cur_depth_min) / (ndepth - 1)  # (B, )
    #     depth_range_samples = cur_depth_min.unsqueeze(1) + (torch.arange(0, ndepth, device=cur_depth_min.device, dtype=cur_depth_min.dtype,
    #                                                                    requires_grad=False).reshape(1, -1) * new_interval.unsqueeze(1)) # (B, D)
    #     depth_range_samples = depth_range_samples.unsqueeze(-1).unsqueeze(-1).repeat(1, 1, cur_depth.shape[1], cur_depth.shape[2]) # (B, D, H, W)
    # else:
    low_bound = -torch.min(cur_depth, exp_var)
    high_bound = exp_var

    # assert exp_var.min() >= 0, exp_var.min()
    assert ndepth > 1

    step = (high_bound - low_bound) / (float(ndepth) - 1)
    new_samps = []
    for i in range(int(ndepth)):
        new_samps.append(cur_depth + low_bound + step * i + eps)

    depth_range_samples = torch.cat(new_samps, 1)
        # assert depth_range_samples.min() >= 0, depth_range_samples.min()
    return depth_range_samples



def conv(in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1):   
    return nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, 
                        padding=padding, dilation=dilation, bias=True),
            nn.LeakyReLU(0.1))

def conditionIntrinsics(intrinsics,img_shape,fp_shapes):
    # Pre-condition intrinsics according to feature pyramid shape.

    # Calculate downsample ratio for each level of feture pyramid
    down_ratios = []
    for fp_shape in fp_shapes:
        down_ratios.append(img_shape[2]/fp_shape[2])

    # condition intrinsics
    intrinsics_out = []
    for down_ratio in down_ratios:
        intrinsics_tmp = intrinsics.clone()
        intrinsics_tmp[:, :2, :] = intrinsics_tmp[:, :2, :] / down_ratio
        intrinsics_out.append(intrinsics_tmp)

    return torch.stack(intrinsics_out).permute(1,0,2,3) # [B, nScale, 3, 3]

def calInitDepthInterval(ref_in, src_in,ref_ex, src_ex, pixel_interval):
    
    return 165 # The mean depth interval calculated on 4-1 interval setting...

def calSweepingDepthHypo(ref_in,src_in,ref_ex,src_ex,depth_min, depth_max, nhypothesis_init=48):
    # # #test scan6
    # depth_min = torch.tensor([0.5904], device='cuda:0', dtype=torch.float64)
    # depth_max = torch.tensor([2.1409], device='cuda:0', dtype=torch.float64)

    # Batch
    batchSize = ref_in.shape[0]
    depth_range = depth_max[0]-depth_min[0]
    depth_interval_mean = depth_range/(nhypothesis_init-1)
    # Make sure the number of depth hypothesis has a factor of 2
    assert nhypothesis_init%2 == 0

    #原版代码，用range一直会报错
    depth_hypos = torch.range(depth_min[0],depth_max[0],depth_interval_mean).unsqueeze(0)

    # depth_hypos_tmp = depth_max.detach().clone().cpu().unsqueeze(0).float()
    # depth_hypos = torch.cat((depth_hypos,depth_hypos_tmp),1)

    #写一个判断，处理不了最后一维数目对不上的情况
    if depth_hypos.shape[1]==(nhypothesis_init-1):
        # depth_hypos_tmp = torch.range(depth_hypos[0,-1],depth_max[0],depth_interval_mean).unsqueeze(0)
        depth_hypos_tmp = depth_max[0].detach().clone().cpu().float().unsqueeze(0).unsqueeze(0)
        depth_hypos = torch.cat((depth_hypos,depth_hypos_tmp),1)
    
    # #gao_test_code
    # depth_interval_mean_gao = (depth_max - depth_min)/(nhypothesis_init-1)
    # depth_hypos = depth_min
    # for i in range(nhypothesis_init):
    #     depth_tmp = depth_min + i*depth_interval_mean_gao
    #     depth_hypos = torch.cat((depth_hypos,depth_tmp),1)

    # Assume depth range is consistent in one batch.
    # for b in range(1,batchSize):
    #     depth_range = depth_max[b]-depth_min[b]
    #     depth_hypos = torch.cat((depth_hypos,torch.range(depth_min[0],depth_max[0],depth_interval_mean).unsqueeze(0)),0)
    for b in range(1,batchSize):
        depth_range_tmp = (depth_max[b]-depth_min[b])/(nhypothesis_init-1)
        depth_hypos_tmp2 = torch.range(depth_min[b],depth_max[b],depth_range_tmp).unsqueeze(0)
        if depth_hypos_tmp2.shape[1]==(nhypothesis_init-1):
            # depth_hypos_tmp = torch.range(depth_hypos[0,-1],depth_max[0],depth_interval_mean).unsqueeze(0)
            depth_hypos_tmp3 = depth_max[b].detach().clone().cpu().float().unsqueeze(0).unsqueeze(0)
            depth_hypos_tmp2 = torch.cat((depth_hypos_tmp2,depth_hypos_tmp3),1)
        depth_hypos = torch.cat((depth_hypos,depth_hypos_tmp2),0)
        
        # depth_hypos = torch.cat((depth_hypos,torch.range(depth_min[b],depth_max[b],depth_range_tmp).unsqueeze(0)),0)

    return depth_hypos.cuda()

def generate_depth_range(depth_min, depth_max, nhypothesis_init=32):
    # depth_min [b,1,h,w]
    depth_min = depth_min.unsqueeze(1)
    depth_max = depth_max.unsqueeze(1)
    depth_interval = (depth_max - depth_min)/(nhypothesis_init - 1)  #b1hw
    range_multiplier = torch.arange(0, nhypothesis_init , 1, device=depth_min.device).view(nhypothesis_init, 1, 1)  #(nhypothesis_init, 1, 1)
    sampled_disparities = depth_min + depth_interval * range_multiplier

    return sampled_disparities


def homo_warping(src_feature, ref_in, src_in, ref_ex, src_ex, depth_hypos):
    # Apply homography warpping on one src feature map from src to ref view.

    batch, channels = src_feature.shape[0], src_feature.shape[1]
    num_depth = depth_hypos.shape[1]
    height, width = src_feature.shape[2], src_feature.shape[3]

    with torch.no_grad():
        src_proj = torch.matmul(src_in,src_ex[:,0:3,:])
        ref_proj = torch.matmul(ref_in,ref_ex[:,0:3,:])
        last = torch.tensor([[[0,0,0,1.0]]]).repeat(len(src_in),1,1).cuda()
        src_proj = torch.cat((src_proj,last),1)
        ref_proj = torch.cat((ref_proj,last),1)

        proj = torch.matmul(src_proj, torch.inverse(ref_proj))
        rot = proj[:, :3, :3]  # [B,3,3]
        trans = proj[:, :3, 3:4]  # [B,3,1]

        y, x = torch.meshgrid([torch.arange(0, height, dtype=torch.float32, device=src_feature.device),
                               torch.arange(0, width, dtype=torch.float32, device=src_feature.device)])
        y, x = y.contiguous(), x.contiguous()
        y, x = y.view(height * width), x.view(height * width)
        xyz = torch.stack((x, y, torch.ones_like(x)))  # [3, H*W]
        xyz = torch.unsqueeze(xyz, 0).repeat(batch, 1, 1)  # [B, 3, H*W]
        rot_xyz = torch.matmul(rot, xyz)  # [B, 3, H*W]
        rot_depth_xyz = rot_xyz.unsqueeze(2).repeat(1, 1, num_depth, 1) * depth_hypos.view(batch, 1, num_depth,1)  # [B, 3, Ndepth, H*W]
        proj_xyz = rot_depth_xyz + trans.view(batch, 3, 1, 1)  # [B, 3, Ndepth, H*W]
        proj_xy = proj_xyz[:, :2, :, :] / proj_xyz[:, 2:3, :, :]  # [B, 2, Ndepth, H*W]
        proj_x_normalized = proj_xy[:, 0, :, :] / ((width - 1) / 2) - 1
        proj_y_normalized = proj_xy[:, 1, :, :] / ((height - 1) / 2) - 1
        proj_xy = torch.stack((proj_x_normalized, proj_y_normalized), dim=3)  # [B, Ndepth, H*W, 2]
        grid = proj_xy

    warped_src_fea = F.grid_sample(src_feature, grid.view(batch, num_depth * height, width, 2), mode='bilinear',
                                   padding_mode='zeros')
    warped_src_fea = warped_src_fea.view(batch, channels, num_depth, height, width)

    return warped_src_fea

# def calDepthHypo(netArgs,ref_depths,ref_intrinsics,src_intrinsics,ref_extrinsics,src_extrinsics,depth_min,depth_max,level):
#     ## Calculate depth hypothesis maps for refine steps

#     nhypothesis_init = 48
#     d = 4   
#     #d = 16
#     # d = 4
#     # print(d)
#     pixel_interval = 1

#     nBatch = ref_depths.shape[0]
#     height = ref_depths.shape[1]
#     width = ref_depths.shape[2]   

#     # src_intrinsics [B,S,scale,3,3]

#     if netArgs.mode == "train":

#         depth_interval = torch.tensor([6.8085]*nBatch).cuda() # Hard code the interval for training on DTU with 1 level of refinement.
#         ###[b,1]
#         depth_hypos = ref_depths.unsqueeze(1).repeat(1,d*2,1,1)
#         for depth_level in range(-d,d):
#             depth_hypos[:,depth_level+d,:,:] += (depth_level)*depth_interval[0]

#         return depth_hypos

#     with torch.no_grad():

#         ref_depths = ref_depths
#         ref_intrinsics = ref_intrinsics.double()
#         src_intrinsics = src_intrinsics.squeeze(1).double()
#         ref_extrinsics = ref_extrinsics.double()
#         src_extrinsics = src_extrinsics.squeeze(1).double()

#         interval_maps = []
#         depth_hypos = ref_depths.unsqueeze(1).repeat(1,d*2,1,1)
#         for batch in range(nBatch):
#             xx, yy = torch.meshgrid([torch.arange(0,width).cuda(),torch.arange(0,height).cuda()])

#             xxx = xx.reshape([-1]).double()
#             yyy = yy.reshape([-1]).double()

#             X = torch.stack([xxx, yyy, torch.ones_like(xxx)],dim=0)

#             D1 = torch.transpose(ref_depths[batch,:,:],0,1).reshape([-1]) # Transpose before reshape to produce identical results to numpy and matlab version.
#             D2 = D1+1

#             X1 = X*D1
#             X2 = X*D2
#             ray1 = torch.matmul(torch.inverse(ref_intrinsics[batch]),X1)
#             ray2 = torch.matmul(torch.inverse(ref_intrinsics[batch]),X2)

#             X1 = torch.cat([ray1, torch.ones_like(xxx).unsqueeze(0).double()],dim=0)
#             X1 = torch.matmul(torch.inverse(ref_extrinsics[batch]),X1)
#             X2 = torch.cat([ray2, torch.ones_like(xxx).unsqueeze(0).double()],dim=0)
#             X2 = torch.matmul(torch.inverse(ref_extrinsics[batch]),X2)

#             X1 = torch.matmul(src_extrinsics[batch][0], X1)
#             X2 = torch.matmul(src_extrinsics[batch][0], X2)

#             X1 = X1[:3]
#             X1 = torch.matmul(src_intrinsics[batch][0],X1)
#             X1_d = X1[2].clone()
#             X1 /= X1_d

#             X2 = X2[:3]
#             X2 = torch.matmul(src_intrinsics[batch][0],X2)
#             X2_d = X2[2].clone()
#             X2 /= X2_d

#             k = (X2[1]-X1[1])/(X2[0]-X1[0])
#             b = X1[1]-k*X1[0]

#             theta = torch.atan(k)
#             X3 = X1+torch.stack([torch.cos(theta)*pixel_interval,torch.sin(theta)*pixel_interval,torch.zeros_like(X1[2,:])],dim=0)

#             A = torch.matmul(ref_intrinsics[batch],ref_extrinsics[batch][:3,:3])
#             tmp = torch.matmul(src_intrinsics[batch][0],src_extrinsics[batch][0,:3,:3])
#             A = torch.matmul(A,torch.inverse(tmp))

#             tmp1 = X1_d*torch.matmul(A,X1)
#             tmp2 = torch.matmul(A,X3)

#             M1 = torch.cat([X.t().unsqueeze(2),tmp2.t().unsqueeze(2)],axis=2)[:,1:,:] + 0.1
#             M2 = tmp1.t()[:,1:]
#             ans = torch.matmul(torch.inverse(M1),M2.unsqueeze(2))
#             delta_d = ans[:,0,0]

#             interval_maps = torch.abs(delta_d).mean().repeat(ref_depths.shape[2],ref_depths.shape[1]).t()

#             for depth_level in range(-d,d):
#                 depth_hypos[batch,depth_level+d,:,:] += depth_level*interval_maps

#         # print("Calculated:")
#         # print(interval_maps[0,0])

#         # pdb.set_trace()

#         return depth_hypos.float() # Return the depth hypothesis map from statistical interval setting.


def calDepthHypo(netArgs,ref_depths,ref_intrinsics,src_intrinsics,ref_extrinsics,src_extrinsics,depth_min,depth_max,level,nhypothesis_init = 8):
    ## Calculate depth hypothesis maps for refine steps

    # nhypothesis_init = 48
    d = int(nhypothesis_init/2)
    pixel_interval = 1

    nBatch = ref_depths.shape[0]     #ref_depths是上采样之后预测的深度图
    height = ref_depths.shape[1]
    width = ref_depths.shape[2]

    if netArgs.mode == "train":

        depth_interval = torch.tensor([6.8085]*nBatch).cuda() # 326.8 Hard code the interval for training on DTU with 1 level of refinement.
        depth_hypos = ref_depths.unsqueeze(1).repeat(1,d*2,1,1)     #深度数目应该为8
        for depth_level in range(-d,d):
            depth_hypos[:,depth_level+d,:,:] += (depth_level)*depth_interval[0]

        return depth_hypos

    with torch.no_grad():

        ref_depths = ref_depths
        ref_intrinsics = ref_intrinsics.double()
        src_intrinsics = src_intrinsics.squeeze(1).double()
        ref_extrinsics = ref_extrinsics.double()
        src_extrinsics = src_extrinsics.squeeze(1).double()

        interval_maps = []
        depth_hypos = ref_depths.unsqueeze(1).repeat(1,d*2,1,1)
        for batch in range(nBatch):
            xx, yy = torch.meshgrid([torch.arange(0,width).cuda(),torch.arange(0,height).cuda()])

            xxx = xx.reshape([-1]).double()    #变成一维？
            yyy = yy.reshape([-1]).double()

            X = torch.stack([xxx, yyy, torch.ones_like(xxx)],dim=0)    #3*n*1 dim

            D1 = torch.transpose(ref_depths[batch,:,:],0,1).reshape([-1]) # Transpose before reshape to produce identical results to numpy and matlab version.
            D2 = D1+1    #n*1

            X1 = X*D1       #
            X2 = X*D2
            ray1 = torch.matmul(torch.inverse(ref_intrinsics[batch]),X1)    #3*n*1
            ray2 = torch.matmul(torch.inverse(ref_intrinsics[batch]),X2)

            X1 = torch.cat([ray1, torch.ones_like(xxx).unsqueeze(0).double()],dim=0)
            X1 = torch.matmul(torch.inverse(ref_extrinsics[batch]),X1)
            X2 = torch.cat([ray2, torch.ones_like(xxx).unsqueeze(0).double()],dim=0)
            X2 = torch.matmul(torch.inverse(ref_extrinsics[batch]),X2)

            X1 = torch.matmul(src_extrinsics[batch][0], X1)
            X2 = torch.matmul(src_extrinsics[batch][0], X2)

            X1 = X1[:3]
            X1 = torch.matmul(src_intrinsics[batch][0],X1)
            X1_d = X1[2].clone()
            X1 /= X1_d

            X2 = X2[:3]
            X2 = torch.matmul(src_intrinsics[batch][0],X2)
            X2_d = X2[2].clone()
            X2 /= X2_d

            k = (X2[1]-X1[1])/(X2[0]-X1[0])    #在xy坐标平面的直线？深度差值为1重投影之后得到的像素差值
            b = X1[1]-k*X1[0]

            theta = torch.atan(k)
            X3 = X1+torch.stack([torch.cos(theta)*pixel_interval,torch.sin(theta)*pixel_interval,torch.zeros_like(X1[2,:])],dim=0)

            # source到ref的投影
            A = torch.matmul(ref_intrinsics[batch],ref_extrinsics[batch][:3,:3])
            tmp = torch.matmul(src_intrinsics[batch][0],src_extrinsics[batch][0,:3,:3])
            A = torch.matmul(A,torch.inverse(tmp))

            #乘以深度得到非齐次坐标，X1是source投影到ref，再重投影回去
            tmp1 = X1_d*torch.matmul(A,X1)      
            tmp2 = torch.matmul(A,X3)     #齐次坐标

            #X是3*n的meshgrid
            M1 = torch.cat([X.t().unsqueeze(2),tmp2.t().unsqueeze(2)],axis=2)[:,1:,:]   ## n*1*1
            M2 = tmp1.t()[:,1:]       ## n*1
            ans = torch.matmul(torch.inverse(M1),M2.unsqueeze(2))
            delta_d = ans[:,0,0]

            interval_maps = torch.abs(delta_d).mean().repeat(ref_depths.shape[2],ref_depths.shape[1]).t()

            for depth_level in range(-d,d):
                depth_hypos[batch,depth_level+d,:,:] += depth_level*interval_maps

        # print("Calculated:")
        # print(interval_maps[0,0])

        # pdb.set_trace()

        return depth_hypos.float() # Return the depth hypothesis map from statistical interval setting.

def proj_cost(settings,ref_feature,src_feature,level,ref_in,src_in,ref_ex,src_ex,depth_hypos):
    ## Calculate the cost volume for refined depth hypothesis selection

    batch, channels = ref_feature.shape[0], ref_feature.shape[1]
    num_depth = depth_hypos.shape[1]
    height, width = ref_feature.shape[2], ref_feature.shape[3]
    nSrc = len(src_feature)

    volume_sum = ref_feature.unsqueeze(2).repeat(1,1,num_depth,1,1)
    volume_sq_sum = volume_sum.pow_(2)

    for src in range(settings.nsrc):

        with torch.no_grad():
            src_proj = torch.matmul(src_in[:,src,:,:],src_ex[:,src,0:3,:])
            ref_proj = torch.matmul(ref_in,ref_ex[:,0:3,:])
            last = torch.tensor([[[0,0,0,1.0]]]).repeat(len(src_in),1,1).cuda()
            src_proj = torch.cat((src_proj,last),1)
            ref_proj = torch.cat((ref_proj,last),1)

            proj = torch.matmul(src_proj, torch.inverse(ref_proj))
            rot = proj[:, :3, :3]
            trans = proj[:, :3, 3:4]

            y, x = torch.meshgrid([torch.arange(0, height, dtype=torch.float32, device=ref_feature.device),
                                   torch.arange(0, width, dtype=torch.float32, device=ref_feature.device)])
            y, x = y.contiguous(), x.contiguous()
            y, x = y.view(height * width), x.view(height * width)
            xyz = torch.stack((x, y, torch.ones_like(x)))
            xyz = torch.unsqueeze(xyz, 0).repeat(batch, 1, 1)
            rot_xyz = torch.matmul(rot, xyz)

            rot_depth_xyz = rot_xyz.unsqueeze(2).repeat(1, 1, num_depth, 1) * depth_hypos.view(batch, 1, num_depth,height*width)  # [B, 3, Ndepth, H*W]
            proj_xyz = rot_depth_xyz + trans.view(batch, 3, 1, 1)
            proj_xy = proj_xyz[:, :2, :, :] / proj_xyz[:, 2:3, :, :]
            proj_x_normalized = proj_xy[:, 0, :, :] / ((width - 1) / 2) - 1
            proj_y_normalized = proj_xy[:, 1, :, :] / ((height - 1) / 2) - 1
            proj_xy = torch.stack((proj_x_normalized, proj_y_normalized), dim=3)
            grid = proj_xy

        warped_src_fea = F.grid_sample(src_feature[src][level], grid.view(batch, num_depth * height, width, 2), mode='bilinear',
                                       padding_mode='zeros')
        warped_src_fea = warped_src_fea.view(batch, channels, num_depth, height, width)

        volume_sum = volume_sum + warped_src_fea
        volume_sq_sum = volume_sq_sum + warped_src_fea.pow_(2)

    cost_volume = volume_sq_sum.div_(settings.nsrc+1).sub_(volume_sum.div_(settings.nsrc+1).pow_(2))
        
    if settings.mode == "test":
        del volume_sum
        del volume_sq_sum
        torch.cuda.empty_cache()

    return cost_volume

def proj_cost_AACVP(Group, settings, ref_feature, src_feature, level, ref_in, src_in, ref_ex, src_ex, depth_hypos):
    ## Calculate the cost volume for refined depth hypothesis selection
    # AACVP Version.
    batch, channels = ref_feature.shape[0], ref_feature.shape[1]
    num_depth = depth_hypos.shape[1]
    height, width = ref_feature.shape[2], ref_feature.shape[3]
    B, C, H, W = ref_feature.shape
    volume_sum = ref_feature.unsqueeze(2).repeat(1, 1, num_depth, 1, 1)
    ref_volume = volume_sum
    ref_volume = ref_volume.view(B, Group, C // Group, *ref_volume.shape[-3:])
    volume_sum = 0
    for src in range(settings.nsrc):
        with torch.no_grad():
            src_proj = torch.matmul(src_in[:, src, :, :], src_ex[:, src, 0:3, :])
            ref_proj = torch.matmul(ref_in, ref_ex[:, 0:3, :])
            last = torch.tensor([[[0, 0, 0, 1.0]]]).repeat(len(src_in), 1, 1).cuda()
            src_proj = torch.cat((src_proj, last), 1)
            ref_proj = torch.cat((ref_proj, last), 1)

            proj = torch.matmul(src_proj, torch.inverse(ref_proj))
            rot = proj[:, :3, :3]
            trans = proj[:, :3, 3:4]

            y, x = torch.meshgrid([torch.arange(0, height, dtype=torch.float32, device=ref_feature.device),
                                   torch.arange(0, width, dtype=torch.float32, device=ref_feature.device)])
            y, x = y.contiguous(), x.contiguous()
            y, x = y.view(height * width), x.view(height * width)
            xyz = torch.stack((x, y, torch.ones_like(x)))
            xyz = torch.unsqueeze(xyz, 0).repeat(batch, 1, 1)
            rot_xyz = torch.matmul(rot, xyz)

            rot_depth_xyz = rot_xyz.unsqueeze(2).repeat(1, 1, num_depth, 1) * depth_hypos.view(batch, 1, num_depth,
                                                                                               height * width)  # [B, 3, Ndepth, H*W]
            proj_xyz = rot_depth_xyz + trans.view(batch, 3, 1, 1)
            proj_xy = proj_xyz[:, :2, :, :] / proj_xyz[:, 2:3, :, :]
            proj_x_normalized = proj_xy[:, 0, :, :] / ((width - 1) / 2) - 1
            proj_y_normalized = proj_xy[:, 1, :, :] / ((height - 1) / 2) - 1
            proj_xy = torch.stack((proj_x_normalized, proj_y_normalized), dim=3)
            grid = proj_xy

        warped_src_fea = F.grid_sample(src_feature[src][level], grid.view(batch, num_depth * height, width, 2),
                                       mode='bilinear',
                                       padding_mode='zeros')
        warped_src_fea = warped_src_fea.view(batch, channels, num_depth, height, width)
        warped_src_fea = warped_src_fea.to(ref_volume.dtype)

        warped_src_fea = warped_src_fea.view(*ref_volume.shape)
        if settings.mode == 'training':
            volume_sum = volume_sum + warped_src_fea  # (B, Group, C//Group, D, h, w)
        else:
            volume_sum += warped_src_fea
        del warped_src_fea

    volume_variance = (volume_sum * ref_volume).mean(2).div_(settings.nsrc)  # (B, Group, D, h, w)
    del volume_sum, ref_volume

    return volume_variance


# MVSNet modules
class ConvBnReLU(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, pad=1):
        super(ConvBnReLU, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride=stride, padding=pad, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        return F.relu(self.bn(self.conv(x)), inplace=True)


class ConvBn(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, pad=1):
        super(ConvBn, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride=stride, padding=pad, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        return self.bn(self.conv(x))


class ConvBnReLU3D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, pad=1):
        super(ConvBnReLU3D, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size, stride=stride, padding=pad, bias=False)
        self.bn = nn.BatchNorm3d(out_channels)

    def forward(self, x):
        return F.relu(self.bn(self.conv(x)), inplace=True)


class ConvBn3D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, pad=1):
        super(ConvBn3D, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size, stride=stride, padding=pad, bias=False)
        self.bn = nn.BatchNorm3d(out_channels)

    def forward(self, x):
        return self.bn(self.conv(x))


class BasicBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride, downsample=None):
        super(BasicBlock, self).__init__()

        self.conv1 = ConvBnReLU(in_channels, out_channels, kernel_size=3, stride=stride, pad=1)
        self.conv2 = ConvBn(out_channels, out_channels, kernel_size=3, stride=1, pad=1)

        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        if self.downsample is not None:
            x = self.downsample(x)
        out += x
        return out


def depth_regression(p, depth_values):
    depth_values = depth_values.view(*depth_values.shape, 1, 1)
    depth = torch.sum(p * depth_values, 1)
    return depth

def depth_regression_refine(prob_volume, depth_hypothesis):
    depth = torch.sum(prob_volume * depth_hypothesis, 1)

    return depth
